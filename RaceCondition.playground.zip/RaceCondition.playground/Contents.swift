
//THIS CODE BELOW SHOWS A RACE CONDITION
//-------------------------------------------------------------------------------------------------------------------

import Foundation

let queue1 = DispatchQueue(label: "com.io.concurrency.1")
let queue2 = DispatchQueue(label: "com.io.concurrency.2")

var userCount = 1000

queue1.async {
    print("queue1")
    if userCount == 1000 {
        sleep(1)
        userCount += 1
        print("queue1: \(userCount)")
    }
}
queue2.async {
    print("queue2")
    userCount = 0
    print("queue2: \(userCount)")
}

//-------------------------------------------------------------------------------------------------------------------

//RESULT

//queue1
//queue2
//queue2: 0
//queue1: 1

//EXPLANATION OF CODE

//Let's examine a code example that demonstrates a fundamental race condition. We observe two distinct DispatchQueues, both responsible for modifying the variable "userCount." Inside the first queue, a condition is checked: "if userCount equals 1000." Should this condition be met, an increment operation follows. At this particular moment, "userCount" is indeed 1000. However, just before the first queue can execute its increment, another thread (queue2) intervenes and changes "userCount" to 0. Consequently, when the first queue resumes its operation, "userCount" no longer holds the value 1000. As a result, after the increment, "userCount" becomes "1." The expected outcome was 1001, but instead, the program prints "1." This occurrence is commonly referred to as a Race Condition.

//-------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------




//THIS CODE BELOW SHOWS A DATA RACE
//-------------------------------------------------------------------------------------------------------------------

import Foundation

let queue = DispatchQueue(label: "com.io.concurrency", attributes: .concurrent)

//UNCOMMENT FOR USING DISPATCHQUEUE
//let safetyQueue = DispatchQueue(label: "com.io.concurrency.sync")

//UNCOMMENT FOR USING SEMAPHORE
let semaphore = DispatchSemaphore(value: 1)

// A helper function to simulate a network response
func delay(_ seconds: Double, _ simulateNetworkResponseTimeDelay: @escaping ()->()) {
    queue.asyncAfter(deadline: .now() + seconds) {
        simulateNetworkResponseTimeDelay()
    }
}

//UNCOMMENT FOR USING NSLOCK
//var lock = NSLock()
//// Handles  result in a thread-safe manner
//func handle(_ result: Result<String, Error>) {
//    lock.lock()
//    defer { lock.unlock() }
//
//    switch result {
//    case .success(let id):
//        imageIds.append(id)
//    case .failure(let error):
//        print(error)
//    }
//}

//UNCOMMENT FOR USING DISPATCHQUEUE
//func handle(_ result: Result<String, Error>) {
//    safetyQueue.sync {
//        switch result {
//        case .success(let id):
//            imageIds.append(id)
//        case .failure(let error):
//            print(error)
//        }
//    }
//}

//UNCOMMENT FOR USING SEMAPHORE
func handle(_ result: Result<String, Error>) {
    semaphore.wait()
    defer { semaphore.signal() }
    switch result {
    case .success(let id):
        imageIds.append(id)
    case .failure(let error):
        print(error)
    }
}

// Simulates API functionality of uploading images
class API {
    static func upload(_ image: String, _ completion: @escaping (Result<String, Error>)->()) {
        delay(1) {
            let imageID = UUID().uuidString
            completion(.success(imageID))
        }
    }
}

// Selected images the user wants to upload
let images = ["image1.png", "image2.png", "image3.png", "image4.png", "image5.png",
              "image6.png", "image7.png", "image8.png", "image9.png", "image10.png"]

// Each image receives an ID after successful upload
var imageIds = [String]()

//UNCOMMENT TO SEE DATA RACE SCENARIO
//Start uploading images for all
for image in images {
    API.upload(image) { result in
        switch result {
        case .success(let id):
            imageIds.append(id)
        case .failure(let error):
            print(error)
        }
    }
}

//USED TO PREVENT DATA RACE. EITHER WITH SEMAPHORE, NSLOCK OR DISATCHQUEUE
//for image in images {
//    API.upload(image) { result in
//        handle(result)
//    }
//}

// Delay printing IDs
DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
    print(imageIds)
    print("Total count: \(imageIds.count)")
}


//-------------------------------------------------------------------------------------------------------------------

//RESULT


//FIRST EXECUTION RESULTS
//-------------------------------------
//["D7223C0F-9D4F-4206-96BD-D64CD3A07180", "669C3D8F-C652-434F-9241-02E273996EF3", "7412864B-A526-406F-9C37-CDE778EB4712", "01208A68-721C-4171-84F8-201E1D328E6C", "2F68140D-F56F-4AD9-871A-691B703CDA64", "9202AB21-4D71-4F6C-8414-1E9BE0FC1AF9", "983D30C2-821D-4760-AA59-06D772EC94EB"]
//Total count: 7
//-------------------------------------


//SECOND EXECUTION RESULTS
//-------------------------------------
//["FB3DF254-FF1F-465C-9E2B-0D34BC5BC772", "87BD9976-EBAE-44DC-A114-08935657C741", "8535787A-2B0C-4BCC-95FC-DA87CE475151", "9970EFBD-C176-401D-A0D5-899965E5F3EC", "965FD00A-F30A-47EE-9235-20820B86002D", "B1E005B4-C112-43BF-A71B-7E64C36BF2E2", "6F902513-CB91-4967-8F60-D53C9961F4DF", "6A0C2B0D-7B37-4F1A-A36A-B477D1EB9FB2", "D5F7A094-6977-4D47-9A58-E5B4CC36C76B", "17FD9A79-1E97-43DF-94B3-68807E91F901"]
//Total count: 10
//-------------------------------------


//THIRD EXECUTION RESULTS
//-------------------------------------
//["60E5C11C-5C37-4065-9E97-AC70AC821818", "2E8CFBF9-8D33-44F5-ADAD-32719EBFBF57", "B7E40B5E-7376-45D7-91C7-0F500A08C747", "84E07150-2502-483A-8544-C9E4D38D46F6", "46D5052B-44FB-413E-8C28-A5B25D642D29", "B1BE7BE2-6BB5-4576-BA9A-F7D43271DBC4"]
//Total count: 6
//-------------------------------------

//EXPLANATION OF CODE

//There is something unusual occurring. Despite uploading 10 images, we only receive 1 ID in response. Occasionally, we may get 8 or 6 IDs instead. The inconsistency raises the question of why this behaviour changes. In real-world applications, such variations can occur due to network failures, server non-responsiveness to some images, or certain processes taking too long, leading to timeout errors. However, in our case, we are merely simulating the process, and all our requests are successful. So, how did this happen? The issue arises when multiple tasks or threads attempt to modify data simultaneously. In our scenario, we have 10 concurrent tasks executing, and upon completion, they all attempt to write to the "imageIds" array, causing a Data Race. These problems could have been prevented if the "append" method were made Thread-Safe. THE SOLUTION TO THIS IS TO USE THREAD SAFETY ON THE APPEND (When a thread is modifying or reading a shared data, no other thread can change it.)


//WAYS ON HOW TO IMPLEMENT THREAD SAFETY
//-------------------------------------
// 1) USE NSLOCK
//-------------------------------------

//var lock = NSLock()
//func handle(_ result: Result<String, Error>) {
//    lock.lock()
//    defer { lock.unlock() }
//
//    switch result {
//    case .success(let id):
//        imageIds.append(id)
//    case .failure(let error):
//        print(error)
//    }
//}

//-------------------------------------
// 2) USE DISPATCHQUEUE
//-------------------------------------

//let safetyQueue = DispatchQueue(label: "com.io.concurrency.sync")

//func handle(_ result: Result<String, Error>) {
//safetyQueue.sync {
//    switch result {
//    case .success(let id):
//        imageIds.append(id)
//    case .failure(let error):
//        print(error)
//    }
//}
//}

//-------------------------------------
//3) USE DISPATCHSEMAPHORE
//-------------------------------------

//let semaphore = DispatchSemaphore(value: 1)
//func handle(_ result: Result<String, Error>) {
//semaphore.wait()
//defer { semaphore.signal() }
//switch result {
//case .success(let id):
//    imageIds.append(id)
//case .failure(let error):
//    print(error)
//}
//}

